<?php
$hash = password_hash("12345", PASSWORD_DEFAULT);

echo "<h2>Hash generado:</h2>";
echo "<p style='font-family: monospace; font-size: 18px;'>$hash</p>";
?>
