<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../libe/rb.php';

use RedBeanPHP\Facade as R;

R::setup(
    'mysql:host=sql205.infinityfree.com;dbname=if0_40134604_Lavanderia',
    'if0_40134604',
    'uMVAJUOhxFh0'
);

// 🔧 En desarrollo
R::freeze(false);

// 🔎 Verificar conexión
if (!R::testConnection()) {
    die('❌ Error: RedBean no pudo conectarse a la base de datos');
}

