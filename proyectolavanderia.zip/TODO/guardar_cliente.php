<?php
include 'config.php';

// Obtener datos del formulario
$nombre    = $_POST['nombre'];
$telefono  = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo    = $_POST['correo'];

// Preparar la consulta SQL segura (evita inyección SQL)
$sql = "INSERT INTO cliente (Nombre, Telefono, Direccion, correo)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nombre, $telefono, $direccion, $correo);

// Ejecutar la consulta e informar al usuario
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro de Cliente</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .contenedor {
        background: #fff;
        padding: 30px 40px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
        text-align: center;
        width: 350px;
    }
    h2 {
        color: #004080;
        margin-bottom: 20px;
    }
    p {
        font-size: 18px;
        margin-bottom: 20px;
    }
    a {
        display: inline-block;
        background-color: #004080;
        color: white;
        padding: 10px 20px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: bold;
        transition: all 0.3s ease;
    }
    a:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }
</style>
</head>
<body>
    <div class="contenedor">
        <?php
        if ($stmt->execute()) {
            $nuevo_id = $conn->insert_id;
            echo "<h2>✅ Registro exitoso</h2>";
            echo "<p>Tu ID de cliente es:<br><strong>$nuevo_id</strong></p>";
            echo "<a href='login_cliente.php'>Iniciar sesión</a>";
        } else {
            echo "<h2>❌ Error en el registro</h2>";
            echo "<p>Ocurrió un error: <br><strong>" . htmlspecialchars($conn->error) . "</strong></p>";
            echo "<a href='menu_cliente.php'>Volver</a>";
        }
        ?>
    </div>
</body>
</html>

