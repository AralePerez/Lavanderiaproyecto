<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login Empleado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #74ebd5, #9face6);
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        background: #fff;
        padding: 40px 50px;
        border-radius: 15px;
        box-shadow: 0 8px 18px rgba(0,0,0,0.2);
        text-align: center;
        width: 350px;
    }

    h2 {
        color: #004080;
        margin-bottom: 30px;
    }

    label {
        font-weight: bold;
        display: block;
        text-align: left;
        margin-bottom: 5px;
    }

    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
    }

    input[type="submit"] {
        background-color: #004080;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.3s ease;
    }

    input[type="submit"]:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #004080;
        text-decoration: none;
        font-weight: bold;
        transition: 0.3s;
    }

    a:hover {
        text-decoration: underline;
        color: #0066cc;
    }
</style>
</head>
<body>

<div class="container">
    <h2>🔐 Login de Empleado</h2>

    <form action="validar_empleado.php" method="POST">
        <label for="correo">Correo:</label>
        <input type="text" id="correo" name="correo" required>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>

        <input type="submit" value="Ingresar">
    </form>

    <a href="menu_empleado.php">⬅️ Volver</a>
</div>

</body>
</html>
