<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registro de Cliente</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        color: #333;
    }

    h2 {
        color: #004080;
        font-size: 2rem;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        margin-bottom: 20px;
    }

    form {
        background-color: #fff;
        padding: 30px 40px;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        width: 320px;
        text-align: left;
    }

    label {
        font-weight: bold;
        color: #004080;
    }

    input[type="text"],
    input[type="email"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        box-sizing: border-box;
    }

    input[type="text"]:focus,
    input[type="email"]:focus {
        border-color: #004080;
        outline: none;
        box-shadow: 0 0 5px rgba(0,64,128,0.5);
    }

    input[type="submit"] {
        width: 100%;
        background-color: #004080;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    input[type="submit"]:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 5px 10px rgba(0,0,0,0.3);
    }

    a {
        display: inline-block;
        margin-top: 20px;
        color: #004080;
        font-weight: bold;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    a:hover {
        color: #001f4d;
        text-decoration: underline;
    }
</style>
</head>
<body>

    <h2>Registro de Cliente</h2>

    <form method="POST" action="guardar_cliente.php">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>

        <label>Teléfono:</label>
        <input type="text" name="telefono" required>

        <label>Dirección:</label>
        <input type="text" name="direccion" required>

        <label>Correo:</label>
        <input type="email" name="correo" required>

        <input type="submit" value="Registrarme">
    </form>

    <a href="menu_cliente.php">⬅️ Volver al menú</a>

</body>
</html>
