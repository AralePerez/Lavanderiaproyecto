<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Menú Empleado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        text-align: center;
        margin: 0;
        padding: 0;
        color: #333;
    }

    .container {
        margin: 100px auto;
        width: 400px;
        background: #fff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
    }

    h2 {
        color: #004080;
        margin-bottom: 30px;
    }

    button {
        width: 80%;
        padding: 15px;
        margin: 10px;
        font-size: 18px;
        background-color: #004080;
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: 0.3s;
    }

    button:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #004080;
        text-decoration: none;
        font-weight: bold;
    }

    a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>

<div class="container">
    <h2>👔 Menú Empleado</h2>

    <form action="login_empleado.php">
        <button type="submit">Iniciar Sesión 🔐</button>
    </form>

    <form action="index.php">
        <button type="submit">⬅️ Regresar</button>
    </form>
</div>

</body>
</html>

