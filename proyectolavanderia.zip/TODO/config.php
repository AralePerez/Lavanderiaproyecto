<?php
$servername = "sql205.infinityfree.com"; // cambia por tu servidor MySQL en InfinityFree
$username = "if0_40134604";     // usuario MySQL
$password = "uMVAJUOhxFh0";       // contraseña MySQL
$dbname = "if0_40134604_Lavanderia";    // nombre de BD

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>