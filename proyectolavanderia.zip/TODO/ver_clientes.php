<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Verificar sesión activa
if (!isset($_SESSION['empleado'])) {
    header("Location: login_empleado.php");
    exit;
}

include 'config.php';

// ✅ Consulta para obtener la lista de clientes
$sql = "SELECT * FROM cliente ORDER BY id_cliente DESC";
$result = $conn->query($sql);

// ✅ Verificar si hay error en la consulta
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Lista de Clientes</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #e0f0ff, #a8d0ff);
        margin: 0;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background: #fff;
        width: 90%;
        max-width: 900px;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.2);
    }

    h2 {
        text-align: center;
        color: #003366;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #004080;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f3f8ff;
    }

    tr:hover {
        background-color: #e0ecff;
    }

    .volver {
        display: block;
        text-align: center;
        margin-top: 20px;
        padding: 10px 20px;
        background: #004080;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: 0.2s;
    }

    .volver:hover {
        background: #0059b3;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .mensaje {
        text-align: center;
        font-size: 18px;
        color: #333;
    }
</style>
</head>
<body>

<div class="container">
    <h2>👥 Lista de Clientes</h2>

    <?php
    if ($result->num_rows == 0) {
        echo "<p class='mensaje'>No hay clientes registrados.</p>";
    } else {
        echo "<table>
                <tr>
                    <th>ID Cliente</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Correo</th>
                </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id_cliente']}</td>
                    <td>{$row['Nombre']}</td>
                    <td>{$row['Telefono']}</td>
                    <td>{$row['Direccion']}</td>
                    <td>{$row['correo']}</td>
                  </tr>";
        }

        echo "</table>";
    }
    ?>

    <a href="panel_empleado.php" class="volver">⬅️ Volver al Panel</a>
</div>

</body>
</html>
