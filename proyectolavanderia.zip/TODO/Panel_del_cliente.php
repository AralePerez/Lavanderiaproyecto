<?php
session_start();
if (!isset($_SESSION['cliente'])) {
    header("Location: login_cliente.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel del Cliente</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .panel {
        background: #fff;
        border-radius: 15px;
        padding: 40px 50px;
        text-align: center;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
        width: 350px;
    }

    h2 {
        color: #004080;
        margin-bottom: 30px;
    }

    a {
        display: block;
        background-color: #004080;
        color: white;
        text-decoration: none;
        padding: 12px;
        margin: 10px 0;
        border-radius: 8px;
        transition: all 0.3s ease;
        font-size: 16px;
        font-weight: bold;
    }

    a:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    .logout {
        background-color: #ff4d4d;
    }

    .logout:hover {
        background-color: #e60000;
    }
</style>
</head>

<body>
    <div class="panel">
        <h2>👋 Bienvenido Cliente #<?php echo $_SESSION['cliente']; ?></h2>

        <a href="form_pedido.php">Hacer un Pedido 🧾</a>
        <a href="mis_pedidos.php">Ver mis pedidos 📋</a>
        <a href="logout.php" class="logout">Cerrar sesión 🚪</a>
    </div>
</body>
</html>
