<?php
include 'config.php';

// ---------------------------------------------------------
// 🧾 1️⃣ Recibir datos del formulario
// ---------------------------------------------------------
$id_cliente       = $_POST['id_cliente'];
$descripcion      = $_POST['descripcion'];
$cuidados         = $_POST['cuidados'] ?? '';
$servicio         = $_POST['servicio'];

// Campos específicos según el tipo de servicio
$tipo_tela        = $_POST['tipo_tela'] ?? null;
$tipo_lavado      = $_POST['tipo_lavado'] ?? null;
$tipo_planchado   = $_POST['tipo_planchado'] ?? null;
$temperatura      = $_POST['temperatura'] ?? null;
$material_calzado = $_POST['material_calzado'] ?? null;
$tipo_limpieza    = $_POST['tipo_limpieza'] ?? null;


// ---------------------------------------------------------
// 📦 2️⃣ Insertar pedido
// ---------------------------------------------------------
$sqlPedido = "INSERT INTO pedido (id_cliente, Fecha_pedido, Estado_pedido)
              VALUES ($id_cliente, CURDATE(), 'Pendiente')";
mysqli_query($conn, $sqlPedido);
$id_pedido = mysqli_insert_id($conn);


// ---------------------------------------------------------
// 👕 3️⃣ Insertar prenda
// ---------------------------------------------------------
$sqlPrenda = "INSERT INTO prenda (id_pedido, Descripcion, Cuidados_especiales)
              VALUES ($id_pedido, '$descripcion', '$cuidados')";
mysqli_query($conn, $sqlPrenda);


// ---------------------------------------------------------
// 💰 4️⃣ Insertar servicio base
// ---------------------------------------------------------
$sqlServicio = "INSERT INTO servicio (Precio_base) VALUES (0)";
mysqli_query($conn, $sqlServicio);
$id_servicio = mysqli_insert_id($conn);


// ---------------------------------------------------------
// 🧼 5️⃣ Insertar según tipo de servicio
// ---------------------------------------------------------
$precio = 0;
$dias_entrega = 0;

if ($servicio == "lavado") {
    $precio = ($tipo_lavado == "seco") ? 90 : 60;
    $dias_entrega = 2;

    $sql = "INSERT INTO lavado (id_servicio, Tipo_tela, Tipo_lavado)
            VALUES ($id_servicio, '$tipo_tela', '$tipo_lavado')";
}

elseif ($servicio == "planchado") {
    $precio = ($tipo_planchado == "vapor") ? 50 : 30;
    $dias_entrega = 1;

    $sql = "INSERT INTO planchado (id_servicio, Tipo_planchado, Temperatura)
            VALUES ($id_servicio, '$tipo_planchado', '$temperatura')";
}

elseif ($servicio == "calzado") {
    $precio = ($tipo_limpieza == "profunda") ? 120 : 80;
    $dias_entrega = 3;

    $sql = "INSERT INTO calzado (id_servicio, Material_calzado, Tipo_limpieza)
            VALUES ($id_servicio, '$material_calzado', '$tipo_limpieza')";
}

mysqli_query($conn, $sql);


// ---------------------------------------------------------
// 💵 6️⃣ Actualizar precio base del servicio
// ---------------------------------------------------------
mysqli_query($conn, "UPDATE servicio SET Precio_base = $precio WHERE id_servicio = $id_servicio");


// ---------------------------------------------------------
// 🔗 7️⃣ Relacionar pedido ↔ servicio
// ---------------------------------------------------------
mysqli_query($conn, "INSERT INTO pedido_servicio (id_pedido, id_servicio)
                     VALUES ($id_pedido, $id_servicio)");


// ---------------------------------------------------------
// 📅 8️⃣ Calcular y guardar fecha de entrega
// ---------------------------------------------------------
$fechaEntregaQuery = mysqli_query($conn, "
    SELECT DATE_ADD(Fecha_pedido, INTERVAL $dias_entrega DAY)
    FROM pedido WHERE id_pedido = $id_pedido
");
$fecha_entrega = mysqli_fetch_array($fechaEntregaQuery)[0];

mysqli_query($conn, "
    UPDATE pedido 
    SET Fecha_entrega = '$fecha_entrega' 
    WHERE id_pedido = $id_pedido
");


// ---------------------------------------------------------
// ✅ 9️⃣ Mensaje final de confirmación
// ---------------------------------------------------------
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Pedido Registrado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .mensaje {
        background: #fff;
        padding: 40px 50px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
        text-align: center;
        width: 400px;
    }

    h2 {
        color: #004080;
        margin-bottom: 25px;
    }

    p {
        font-size: 16px;
        margin-bottom: 10px;
    }

    strong {
        color: #0066cc;
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #004080;
        text-decoration: none;
        font-weight: bold;
        background: #e6f0ff;
        padding: 10px 15px;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    a:hover {
        background: #004080;
        color: white;
        transform: translateY(-2px);
    }
</style>
</head>

<body>
    <div class="mensaje">
        <h2>✅ Pedido guardado correctamente</h2>
        <p><strong>Precio total:</strong> $<?php echo $precio; ?></p>
        <p><strong>Fecha estimada de entrega:</strong> <?php echo $fecha_entrega; ?></p>
        <a href="form_pedido.php">Registrar otro pedido</a>
        <br><br>
        <a href="Panel_del_cliente.php">Volver al Panel</a>
    </div>
</body>
</html>
