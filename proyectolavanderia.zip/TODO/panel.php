<?php
session_start();
if (!isset($_SESSION['cliente'])) {
    header("Location: index.php");
    exit();
}
echo "<h2>Bienvenido cliente #" . $_SESSION['cliente'] . "</h2>";
?>

<a href="mis_pedidos.php">Ver mis pedidos</a><br>
<a href="logout.php">Salir</a>
