<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lavandería AA</title>
<style>
    /* --- ESTILO GENERAL --- */
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background: linear-gradient(135deg, #a2d9ff, #ffffff);
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    /* --- TARJETA CENTRAL --- */
    .container {
        background: #fff;
        padding: 40px 60px;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        text-align: center;
        width: 350px;
        transition: transform 0.3s ease;
    }

    .container:hover {
        transform: scale(1.02);
    }

    /* --- TITULO E IMAGEN --- */
    h1 {
        color: #0077b6;
        margin-bottom: 10px;
        font-size: 28px;
    }

    img {
        border-radius: 50%;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        margin: 15px 0;
    }

    p {
        font-size: 18px;
        color: #555;
        margin-bottom: 25px;
    }

    /* --- BOTONES --- */
    button {
        width: 100%;
        padding: 15px;
        margin: 10px 0;
        font-size: 18px;
        border: none;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-weight: bold;
    }

    button:hover {
        transform: scale(1.05);
    }

    /* Colores distintos por tipo de usuario */
    .cliente-btn {
        background: #48cae4;
        color: white;
    }
    .cliente-btn:hover {
        background: #00b4d8;
    }

    .empleado-btn {
        background: #90be6d;
        color: white;
    }
    .empleado-btn:hover {
        background: #74c69d;
    }
</style>
</head>
<body>

<div class="container">
    <h1>Lavandería AA</h1>
    <img src="messi.png.jpg" alt="Logo Lavandería AA" width="150">
    <p>Selecciona tu tipo de usuario</p>

    <form action="menu_cliente.php">
        <button type="submit" class="cliente-btn">Cliente 👤</button>
    </form>

    <form action="menu_empleado.php">
        <button type="submit" class="empleado-btn">Empleado 🧑‍🔧</button>
    </form>
</div>

</body>
</html>
