<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registrar Pedido</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .formulario {
        background: #fff;
        padding: 40px 50px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
        width: 420px;
        text-align: center;
    }

    h2 {
        color: #004080;
        margin-bottom: 25px;
    }

    label {
        font-weight: bold;
        display: block;
        text-align: left;
        margin-bottom: 5px;
        color: #333;
    }

    input[type="text"],
    input[type="number"],
    select {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 15px;
        box-sizing: border-box;
    }

    button {
        background-color: #004080;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        font-weight: bold;
        width: 100%;
        transition: all 0.3s ease;
    }

    button:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #004080;
        text-decoration: none;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    a:hover {
        color: #0066cc;
        text-decoration: underline;
    }

    .campo-extra {
        background: #f7faff;
        border: 1px solid #cfe2ff;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 20px;
        display: none;
        text-align: left;
    }
</style>

<script>
function mostrarCampos() {
    let servicio = document.getElementById("servicio").value;

    // Ocultar todos los bloques
    document.getElementById("lavado_fields").style.display = "none";
    document.getElementById("planchado_fields").style.display = "none";
    document.getElementById("calzado_fields").style.display = "none";

    // Mostrar el bloque correspondiente
    if (servicio === "lavado") {
        document.getElementById("lavado_fields").style.display = "block";
    } 
    else if (servicio === "planchado") {
        document.getElementById("planchado_fields").style.display = "block";
    } 
    else if (servicio === "calzado") {
        document.getElementById("calzado_fields").style.display = "block";
    }
}
</script>
</head>

<body>
    <div class="formulario">
        <h2>🧺 Registrar Pedido</h2>

        <form action="guardar_pedido.php" method="POST">
            <label>ID Cliente:</label>
            <input type="number" name="id_cliente" required>

            <label>Descripción de la prenda:</label>
            <input type="text" name="descripcion" required>

            <label>Cuidados especiales:</label>
            <input type="text" name="cuidados">

            <label>Tipo de servicio:</label>
            <select name="servicio" id="servicio" onchange="mostrarCampos()" required>
                <option value="">Seleccione...</option>
                <option value="lavado">Lavado</option>
                <option value="planchado">Planchado</option>
                <option value="calzado">Calzado</option>
            </select>

            <!-- CAMPOS LAVADO -->
            <div id="lavado_fields" class="campo-extra">
                <label>Tipo de tela:</label>
                <input type="text" name="tipo_tela">

                <label>Tipo de lavado:</label>
                <input type="text" name="tipo_lavado">
            </div>

            <!-- CAMPOS PLANCHADO -->
            <div id="planchado_fields" class="campo-extra">
                <label>Tipo de planchado:</label>
                <input type="text" name="tipo_planchado">

                <label>Temperatura:</label>
                <input type="text" name="temperatura">
            </div>

            <!-- CAMPOS CALZADO -->
            <div id="calzado_fields" class="campo-extra">
                <label>Material del calzado:</label>
                <input type="text" name="material_calzado">

                <label>Tipo de limpieza:</label>
                <input type="text" name="tipo_limpieza">
            </div>

            <button type="submit">Registrar Pedido 🧾</button>
        </form>

        <a href="Panel_del_cliente.php">⬅️ Volver</a>
    </div>
</body>
</html>
