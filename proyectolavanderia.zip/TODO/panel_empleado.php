<?php
session_start();

if (!isset($_SESSION['empleado'])) {
    header("Location: login_empleado.php");
    exit;
}

$nombre = $_SESSION['nombre_empleado'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel del Empleado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        margin: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .panel {
        background: #fff;
        width: 400px;
        padding: 40px;
        border-radius: 14px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        text-align: center;
    }

    h2 {
        color: #004080;
        margin-bottom: 25px;
    }

    a {
        display: block;
        background: #004080;
        color: #fff;
        text-decoration: none;
        padding: 12px 20px;
        margin: 10px auto;
        width: 220px;
        border-radius: 8px;
        font-weight: bold;
        transition: 0.2s;
    }

    a:hover {
        background: #0059b3;
        transform: translateY(-3px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.2);
    }

    .logout {
        background: #e6f0ff;
        color: #004080;
    }

    .logout:hover {
        background: #d2e3ff;
    }
</style>
</head>
<body>

<div class="panel">
    <h2>👋 Bienvenido(a), <?php echo htmlspecialchars($nombre); ?></h2>

    <a href="ver_pedidos.php">Ver pedidos 📋</a>
    <a href="ver_clientes.php">Ver clientes 👥</a>
    <a href="logout_empleado.php" class="logout">Cerrar sesión 🚪</a>
</div>

</body>
</html>
