<!DOCTYPE html>
<html>
<head>
<title>Hacer Pedido</title>
<style>
body { font-family: Arial; text-align: center; margin-top: 100px; }
button { width: 240px; padding: 15px; margin: 10px; font-size: 18px; }
</style>
</head>
<body>

<h2>Hacer Pedido</h2>

<form action="login_cliente.php">
    <button type="submit">Ya soy cliente 🔐</button>
</form>

<form action="clientesr.php">
    <button type="submit">Registrarme primero 📝</button>
</form>

<form action="index.php">
    <button type="submit">⬅️ Regresar</button>
</form>

</body>
</html>
