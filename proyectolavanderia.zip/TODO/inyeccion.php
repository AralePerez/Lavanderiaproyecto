<?php
session_start();
include 'config.php';

$correo = $_POST['correo'];
$password = $_POST['password'];

$sql = "SELECT * FROM empleado WHERE correo='$correo' AND password='$password'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $empleado = mysqli_fetch_assoc($result);

    $_SESSION['empleado'] = $empleado['id_empleado']; // Guardar sesión
    $_SESSION['nombre_empleado'] = $empleado['Nombre'];

    header("Location: panel_empleado.php");
    exit;
} else {
    echo "<h3>❌ Credenciales incorrectas</h3>";
    echo "<a href='login_empleado.php'>Volver</a>";
}
?>
