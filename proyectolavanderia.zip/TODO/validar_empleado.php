<?php
session_start();
include 'config.php';

$correo   = $_POST['correo'];
$password = $_POST['password'];

$sql = "SELECT * FROM empleado WHERE correo='$correo' AND password='$password'";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Validar Empleado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        margin: 0;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #333;
    }

    .card {
        background: #fff;
        width: 380px;
        max-width: calc(100% - 40px);
        border-radius: 14px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 36px 28px;
        text-align: center;
    }

    h2 {
        color: #004080;
        margin: 0 0 18px 0;
        font-size: 1.5rem;
    }

    p.msg {
        font-size: 16px;
        margin: 14px 0;
    }

    .ok {
        color: #047857; /* verde */
        font-weight: bold;
    }

    .err {
        color: #b91c1c; /* rojo */
        font-weight: bold;
    }

    .btn {
        display: inline-block;
        background: #004080;
        color: #fff;
        padding: 10px 18px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 700;
        margin-top: 12px;
        transition: transform .18s ease, box-shadow .18s ease;
    }

    .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 18px rgba(0,0,0,0.16);
    }

    .secondary {
        background: #e6f0ff;
        color: #004080;
        display: inline-block;
        margin-left: 10px;
        padding: 8px 14px;
    }

    small.info {
        display: block;
        margin-top: 12px;
        color: #666;
        font-size: 13px;
    }
</style>
</head>
<body>
    <div class="card">
        <h2>🔐 Validando empleado</h2>

<?php
if ($result && mysqli_num_rows($result) > 0) {
    $empleado = mysqli_fetch_assoc($result);

    // Guardar datos de sesión (misma lógica original)
    $_SESSION['empleado'] = $empleado['id_empleado'];
    $_SESSION['nombre_empleado'] = $empleado['Nombre'];

    // Mensaje de éxito
    echo '<p class="msg ok">✅ Inicio de sesión correcto</p>';
    // Mostrar nombre (si existe) — presentación solamente
    if (!empty($empleado['Nombre'])) {
        echo '<p class="msg">Bienvenido, <strong>' . htmlspecialchars($empleado['Nombre']) . '</strong></p>';
    }

    // enlace a panel
    echo '<a class="btn" href="panel_empleado.php">Ir al Panel</a>';
    echo '<small class="info">Si no te redirige automáticamente, haz clic en "Ir al Panel".</small>';

    // redirección (mantengo la misma que tenías)
    header("Refresh:1; url=panel_empleado.php");
    exit;
} else {
    // Mensaje de error (misma lógica original)
    echo '<p class="msg err">❌ Credenciales incorrectas</p>';
    echo '<a class="btn secondary" href="login_empleado.php">Volver</a>';
}
?>
    </div>
</body>
</html>

