<?php
session_start();
include 'config.php';

// -------------------------------------------------------------
// 🔒 Verificar sesión del cliente
// -------------------------------------------------------------
if (!isset($_SESSION['cliente'])) {
    header("Location: login_cliente.php");
    exit();
}

$id_cliente = $_SESSION['cliente'];

// -------------------------------------------------------------
// 📦 Consultar pedidos del cliente
// -------------------------------------------------------------
$sql = "SELECT id_pedido, Fecha_pedido, Fecha_entrega, Estado_pedido 
        FROM pedido 
        WHERE id_cliente = $id_cliente
        ORDER BY id_pedido DESC";

$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Pedidos</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        color: #333;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 80%;
        margin: 50px auto;
        background: #fff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    h2 {
        text-align: center;
        color: #004080;
        margin-bottom: 30px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        text-align: center;
    }

    th, td {
        padding: 12px;
        border-bottom: 1px solid #ddd;
    }

    th {
        background: #004080;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #e6f0ff;
    }

    .no-pedidos {
        text-align: center;
        font-size: 18px;
        color: #555;
        margin-top: 20px;
    }

    .boton-volver {
        display: inline-block;
        margin-top: 25px;
        background: #004080;
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 8px;
        transition: 0.3s ease;
    }

    .boton-volver:hover {
        background: #0066cc;
        transform: translateY(-2px);
    }
</style>
</head>

<body>
<div class="container">
    <h2>📋 Mis Pedidos</h2>

    <?php if ($res->num_rows > 0): ?>
        <table>
            <tr>
                <th>ID Pedido</th>
                <th>Fecha del Pedido</th>
                <th>Fecha de Entrega</th>
                <th>Estado</th>
            </tr>
            <?php while ($row = $res->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_pedido']; ?></td>
                    <td><?php echo $row['Fecha_pedido']; ?></td>
                    <td><?php echo $row['Fecha_entrega'] ?: '—'; ?></td>
                    <td><?php echo $row['Estado_pedido']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p class="no-pedidos">No tienes pedidos todavía 🕓</p>
    <?php endif; ?>

    <div style="text-align:center;">
        <a href="Panel_del_cliente.php" class="boton-volver">⬅ Volver al Panel</a>
    </div>
</div>
</body>
</html>
