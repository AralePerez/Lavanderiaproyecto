<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<title>Menú Cliente</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        color: #333;
    }

    h2 {
        font-size: 2rem;
        margin-bottom: 30px;
        color: #004080;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
    }

    form {
        margin: 10px; //separacion  entre botones
    }

    button {
        width: 260px;
        padding: 15px;
        font-size: 18px;
        font-weight: bold;
        border: none;
        border-radius: 10px;
        background-color: #fff;
        color: #004080;
        box-shadow: 0 4px 6px rgba(0,0,0,0.2);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    button:hover {
        background-color: #004080;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.3);
    }

    button:active {
        transform: scale(0.98);
    }
</style>
</head>
<body>

    <h2>Menú Cliente</h2>

    <form action="clientesr.php">
        <button type="submit">📝 Registrarse</button>
    </form>

    <form action="login_cliente.php">
        <button type="submit">🔐 Iniciar Sesión</button>
    </form>

    <form action="index.php">
        <button type="submit">⬅️ Regresar</button>
    </form>

</body>
</html>
