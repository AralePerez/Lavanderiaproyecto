<?php
session_start();

if (!isset($_SESSION['cliente'])) {
    header("Location: login_cliente.php");
    exit;
}

require_once __DIR__ . '/config/database.php';

// 🔐 ID del cliente logueado
$cliente_id = $_SESSION['cliente'];

// 🔍 Consulta SQL directa (SIN RedBean Beans)
$pedidos = R::getAll(
    "SELECT id_pedido, Fecha_pedido, Fecha_entrega, Estado_pedido
     FROM pedido
     WHERE id_cliente = ?
     ORDER BY id_pedido DESC",
    [$cliente_id]
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Pedidos</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f2f6ff;
        padding: 40px;
    }
    h2 {
        color: #004080;
        text-align: center;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 30px;
        background: white;
    }
    th, td {
        padding: 10px;
        border: 1px solid #ccc;
        text-align: center;
    }
    th {
        background: #004080;
        color: white;
    }
    tr:nth-child(even) {
        background: #f1f5ff;
    }
    .mensaje {
        text-align: center;
        margin-top: 30px;
        font-size: 18px;
    }
</style>
</head>
<body>

<h2>📦 Mis Pedidos</h2>

<?php if (count($pedidos) === 0): ?>
    <p class="mensaje">❌ No tienes pedidos registrados.</p>
<?php else: ?>
    <table>
        <tr>
            <th>ID Pedido</th>
            <th>Fecha Pedido</th>
            <th>Fecha Entrega</th>
            <th>Estado</th>
        </tr>

        <?php foreach ($pedidos as $pedido): ?>
        <tr>
            <td><?= $pedido['id_pedido'] ?></td>
            <td><?= $pedido['Fecha_pedido'] ?></td>
            <td><?= $pedido['Fecha_entrega'] ?></td>
            <td><?= $pedido['Estado_pedido'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

</body>
</html>
