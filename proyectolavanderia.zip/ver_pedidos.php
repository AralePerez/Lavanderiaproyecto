<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Verificar que haya sesión activa del empleado
if (!isset($_SESSION['empleado'])) {
    header("Location: login_empleado.php");
    exit;
}

include 'config.php';

// ✅ Consulta: obtener todos los pedidos ordenados del más reciente al más antiguo
$sql = "SELECT * FROM pedido ORDER BY id_pedido DESC";
$result = $conn->query($sql);

// ✅ Si la consulta falla, mostrar error
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Lista de Pedidos</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #d9e7ff, #a8c8ff);
        margin: 0;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background: white;
        width: 90%;
        max-width: 900px;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.2);
    }

    h2 {
        text-align: center;
        color: #003366;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #004080;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f2f7ff;
    }

    tr:hover {
        background-color: #dce6ff;
    }

    .volver {
        display: block;
        text-align: center;
        margin-top: 20px;
        padding: 10px 20px;
        background: #004080;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: 0.2s;
    }

    .volver:hover {
        background: #0059b3;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .mensaje {
        text-align: center;
        font-size: 18px;
        color: #333;
    }
</style>
</head>
<body>

<div class="container">
    <h2>📋 Lista de Pedidos</h2>

    <?php
    if ($result->num_rows == 0) {
        echo "<p class='mensaje'>No hay pedidos registrados.</p>";
    } else {
        echo "<table>
                <tr>
                    <th>ID Pedido</th>
                    <th>ID Cliente</th>
                    <th>Fecha Pedido</th>
                    <th>Fecha Entrega</th>
                    <th>Estado</th>
                </tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id_pedido']}</td>
                    <td>{$row['id_cliente']}</td>
                    <td>{$row['fecha_pedido']}</td>
                    <td>{$row['fecha_entrega']}</td>
                    <td>{$row['estado_pedido']}</td>
                  </tr>";
        }
        echo "</table>";
    }
    ?>

    <a href="panel_empleado.php" class="volver">⬅️ Volver al Panel</a>
</div>

</body>
</html>
