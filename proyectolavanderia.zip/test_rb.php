<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/config/database.php';

echo R::testConnection() ? "✅ RedBean OK" : "❌ Error";
