<?php
session_start();
if (!isset($_SESSION['cliente'])) { header("Location: login_cliente.php"); exit; }
?>
<h2>Bienvenido Cliente #<?php echo $_SESSION['cliente']; ?></h2>

<a href="form_pedido.php">Hacer un Pedido 🧾</a><br><br>
<a href="mis_pedidos.php">Ver mis pedidos 📋</a><br><br>
<a href="logout.php">Cerrar sesión 🚪</a>
