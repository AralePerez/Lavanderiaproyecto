<?php
include 'config.php';

$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo = $_POST['correo'];

$sql = "INSERT INTO cliente (Nombre, Telefono, Direccion, correo)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nombre, $telefono, $direccion, $correo);

if ($stmt->execute()) {
    echo "Registro exitoso ✅ <br>";
    echo "<a href='login_cliente.php'>Iniciar sesión</a>";
} else {
    echo "Error ❌: " . $conn->error;
}
?>
