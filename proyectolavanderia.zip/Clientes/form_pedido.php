<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Hacer Pedido</title>

<script>
function mostrarCampos() {
    let servicio = document.getElementById("servicio").value;

    // Ocultar todos los campos
    document.getElementById("lavado_fields").style.display = "none";
    document.getElementById("planchado_fields").style.display = "none";
    document.getElementById("calzado_fields").style.display = "none";

    if (servicio === "lavado") {
        document.getElementById("lavado_fields").style.display = "block";
    } 
    else if (servicio === "planchado") {
        document.getElementById("planchado_fields").style.display = "block";
    }
    else if (servicio === "calzado") {
        document.getElementById("calzado_fields").style.display = "block";
    }
}
</script>
</head>
<body>

<h2>Registrar Pedido</h2>

<form action="guardar_pedido.php" method="POST">

    <label>ID Cliente:</label>
    <input type="number" name="id_cliente" required><br><br>

    <label>Descripción de la prenda:</label>
    <input type="text" name="descripcion" required><br><br>

    <label>Cuidados especiales:</label>
    <input type="text" name="cuidados"><br><br>

    <label>Tipo de servicio:</label>
    <select name="servicio" id="servicio" onchange="mostrarCampos()" required>
        <option value="">Seleccione...</option>
        <option value="lavado">Lavado</option>
        <option value="planchado">Planchado</option>
        <option value="calzado">Calzado</option>
    </select><br><br>

    <!-- CAMPOS LAVADO -->
    <div id="lavado_fields" style="display:none;">
        <label>Tipo de tela:</label>
        <input type="text" name="tipo_tela"><br><br>

        <label>Tipo de lavado:</label>
        <input type="text" name="tipo_lavado"><br><br>
    </div>

    <!-- CAMPOS PLANCHADO -->
    <div id="planchado_fields" style="display:none;">
        <label>Tipo de planchado:</label>
        <input type="text" name="tipo_planchado"><br><br>

        <label>Temperatura:</label>
        <input type="text" name="temperatura"><br><br>
    </div>

    <!-- CAMPOS CALZADO -->
    <div id="calzado_fields" style="display:none;">
        <label>Material del calzado:</label>
        <input type="text" name="material_calzado"><br><br>

        <label>Tipo de limpieza:</label>
        <input type="text" name="tipo_limpieza"><br><br>
    </div>

    <button type="submit">Registrar Pedido</button>
</form>

</body>
</html>
