<?php
session_start();
include 'config.php';

$id = $_POST['id'];
$correo = $_POST['correo'];

$sql = "SELECT * FROM cliente WHERE id_cliente = ? AND correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $id, $correo);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $_SESSION['cliente'] = $id;
    header("Location: Panel_del_cliente.php");
} else {
    echo "Datos incorrectos ❌<br><a href='login_cliente.php'>Volver</a>";
}
