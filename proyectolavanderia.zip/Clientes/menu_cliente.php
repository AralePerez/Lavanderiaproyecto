<!DOCTYPE html>
<html>
<head>
<title>Menú Cliente</title>
<style>
body {
    font-family: Arial;
    text-align: center;
    margin-top: 100px;
}
button {
    width: 240px;
    padding: 15px;
    margin: 10px;
    font-size: 18px;
}
</style>
</head>
<body>

<h2>Menú Cliente</h2>

<form action="clientesr.php">
    <button type="submit">Registrarse 📝</button>
</form>

<form action="login_cliente.php">
    <button type="submit">Iniciar Sesión 🔐</button>
</form>

<form action="index.php">
    <button type="submit">⬅️ Regresar</button>
</form>

</body>
</html>
