<!DOCTYPE html>
<html>
<head>
<title>Login Cliente</title>
</head>
<body>
<h2>Iniciar Sesión Cliente</h2>

<form method="POST" action="validarc.php">
    Correo: <input type="email" name="correo" required><br><br>
    ID Cliente: <input type="number" name="id" required><br><br>
    <input type="submit" value="Entrar">
</form>

<a href="menu_cliente.php">Volver</a>
</body>
</html>
