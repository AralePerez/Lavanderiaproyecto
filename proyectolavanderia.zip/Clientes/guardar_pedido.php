<?php
include 'config.php';

// ✅ Recibir datos del formulario
$id_cliente = $_POST['id_cliente'];
$descripcion = $_POST['descripcion'];
$cuidados = $_POST['cuidados'] ?? '';
$servicio = $_POST['servicio'];

// ✅ Campos según servicio
$tipo_tela = $_POST['tipo_tela'] ?? null;
$tipo_lavado = $_POST['tipo_lavado'] ?? null;

$tipo_planchado = $_POST['tipo_planchado'] ?? null;
$temperatura = $_POST['temperatura'] ?? null;

$material_calzado = $_POST['material_calzado'] ?? null;
$tipo_limpieza = $_POST['tipo_limpieza'] ?? null;


// ✅ 1) Insertar pedido
$sqlPedido = "INSERT INTO pedido (id_cliente, Fecha_pedido, Estado_pedido)
              VALUES ($id_cliente, CURDATE(), 'Pendiente')";
mysqli_query($conn, $sqlPedido);
$id_pedido = mysqli_insert_id($conn);


// ✅ 2) Insertar prenda
$sqlPrenda = "INSERT INTO prenda (id_pedido, Descripcion, Cuidados_especiales)
              VALUES ($id_pedido, '$descripcion', '$cuidados')";
mysqli_query($conn, $sqlPrenda);


// ✅ 3) Insertar servicio base
$sqlServicio = "INSERT INTO servicio (Precio_base) VALUES (0)";
mysqli_query($conn, $sqlServicio);
$id_servicio = mysqli_insert_id($conn);


// ✅ 4) Insertar según el tipo de servicio y precio
$precio = 0;
$dias_entrega = 0;

if ($servicio == "lavado") {
    $precio = ($tipo_lavado == "seco") ? 90 : 60;
    $dias_entrega = 2;

    $sql = "INSERT INTO lavado (id_servicio, Tipo_tela, Tipo_lavado)
            VALUES ($id_servicio, '$tipo_tela', '$tipo_lavado')";
}

elseif ($servicio == "planchado") {
    $precio = ($tipo_planchado == "vapor") ? 50 : 30;
    $dias_entrega = 1;

    $sql = "INSERT INTO planchado (id_servicio, Tipo_planchado, Temperatura)
            VALUES ($id_servicio, '$tipo_planchado', '$temperatura')";
}

elseif ($servicio == "calzado") {
    $precio = ($tipo_limpieza == "profunda") ? 120 : 80;
    $dias_entrega = 3;

    $sql = "INSERT INTO calzado (id_servicio, Material_calzado, Tipo_limpieza)
            VALUES ($id_servicio, '$material_calzado', '$tipo_limpieza')";
}

mysqli_query($conn, $sql);


// ✅ Actualizar precio final del servicio
mysqli_query($conn, "UPDATE servicio SET Precio_base = $precio WHERE id_servicio = $id_servicio");


// ✅ Relación pedido ↔ servicio
mysqli_query($conn, "INSERT INTO pedido_servicio (id_pedido, id_servicio)
                VALUES ($id_pedido, $id_servicio)");


// ✅ Calcular fecha entrega
$fechaEntregaQuery = mysqli_query($conn, "SELECT DATE_ADD(Fecha_pedido, INTERVAL $dias_entrega DAY) 
                                          FROM pedido WHERE id_pedido = $id_pedido");
$fecha_entrega = mysqli_fetch_array($fechaEntregaQuery)[0];

// ✅ Guardar fecha de entrega en la tabla pedido
mysqli_query($conn, "UPDATE pedido 
                     SET Fecha_entrega = '$fecha_entrega' 
                     WHERE id_pedido = $id_pedido");



// ✅ Mensaje final
echo "<h2>✅ Pedido guardado correctamente</h2>";
echo "<p><strong>Precio total:</strong> $$precio</p>";
echo "<p><strong>Fecha estimada de entrega:</strong> $fecha_entrega</p>";
echo "<p><a href='form_pedido.php'>Registrar otro pedido</a></p>";
?>
