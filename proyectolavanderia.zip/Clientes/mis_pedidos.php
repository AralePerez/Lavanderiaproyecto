<?php
session_start();
include 'config.php';

// ✅ Verificar sesión
if (!isset($_SESSION['cliente'])) {
    header("Location: login_cliente.php");
    exit();
}

$id_cliente = $_SESSION['cliente'];

// ✅ Traer pedidos del cliente
$sql = "SELECT id_pedido, Fecha_pedido, Fecha_entrega, Estado_pedido 
        FROM pedido 
        WHERE id_cliente = $id_cliente
        ORDER BY id_pedido DESC";

$res = $conn->query($sql);

echo "<h2>Mis pedidos</h2>";

if ($res->num_rows > 0) {
    echo "<table border='1' cellpadding='6'>
            <tr>
                <th>ID Pedido</th>
                <th>Fecha Pedido</th>
                <th>Fecha Entrega</th>
                <th>Estado</th>
            </tr>";

    while ($row = $res->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id_pedido']}</td>
                <td>{$row['Fecha_pedido']}</td>
                <td>{$row['Fecha_entrega']}</td>
                <td>{$row['Estado_pedido']}</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "No tienes pedidos todavía.";
}

echo "<br><br><a href='Panel_del_cliente.php'>Volver</a>";
?>
