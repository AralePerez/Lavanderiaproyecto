<!DOCTYPE html>
<html>
<head>
<title>Registro de Cliente</title>
</head>
<body>
<h2>Registro de Cliente</h2>

<form method="POST" action="guardar_cliente.php">
    Nombre: <input type="text" name="nombre" required><br><br>
    Teléfono: <input type="text" name="telefono" required><br><br>
    Dirección: <input type="text" name="direccion" required><br><br>
    Correo: <input type="email" name="correo" required><br><br>

    <input type="submit" value="Registrarme">
</form>

<a href="menu_cliente.php">Volver</a>
</body>
</html>
