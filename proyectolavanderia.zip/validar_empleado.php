<?php
session_start();
include 'config.php';

// Validar datos del formulario
$correo = filter_input(INPUT_POST, 'correo', FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';

$status = '';
$mensaje = '';

if (!$correo || $password === '') {
    $status = 'error';
    $mensaje = '❌ Credenciales inválidas.';
} else {

    // Obtener empleado por correo
    $sql = "SELECT id_empleado, Nombre, password FROM empleado WHERE correo = ? LIMIT 1";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        $status = 'fatal';
        $mensaje = '❌ Error al preparar consulta.';
        error_log("DB prepare error: " . $conn->error);
    } else {

        // Enlazar el parámetro
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();
        $empleado = $result->fetch_assoc();
        $stmt->close();

        // Verificar usuario y contraseña (HASH)
        if (!$empleado || !password_verify($password, $empleado['password'])) {
            $status = 'error';
            $mensaje = '❌ Credenciales incorrectas.';
        } else {

            // Iniciar sesión
            session_regenerate_id(true);
            $_SESSION['empleado'] = $empleado['id_empleado'];
            $_SESSION['nombre_empleado'] = $empleado['Nombre'];

            $status = 'ok';
            $mensaje = '✅ Inicio de sesión correcto. Redirigiendo al panel...';

            // Redirigir
            header("Refresh:1; url=panel_empleado.php");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Validar Empleado</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #89f7fe, #66a6ff);
        margin: 0;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #333;
    }

    .card {
        background: #fff;
        width: 380px;
        max-width: calc(100% - 40px);
        border-radius: 14px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 36px 28px;
        text-align: center;
    }

    h2 {
        color: #004080;
        margin: 0 0 18px 0;
        font-size: 1.4rem;
    }

    p.msg {
        font-size: 16px;
        margin: 14px 0;
    }

    .ok { color: #047857; font-weight: 700; }    /* verde */
    .err { color: #b91c1c; font-weight: 700; }   /* rojo */
    .info { color: #0c4a6e; }

    .btn {
        display: inline-block;
        background: #004080;
        color: #fff;
        padding: 10px 18px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 700;
        margin-top: 12px;
        transition: transform .18s ease, box-shadow .18s ease;
    }

    .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 18px rgba(0,0,0,0.16);
    }

    .secondary {
        background: #e6f0ff;
        color: #004080;
        display: inline-block;
        margin-left: 10px;
        padding: 8px 14px;
    }

    small.info {
        display: block;
        margin-top: 12px;
        color: #666;
        font-size: 13px;
    }
</style>
</head>
<body>
    <div class="card">
        <h2>🔐 Validando empleado</h2>

        <?php if ($status === 'fatal'): ?>
            <p class="msg err"><?php echo htmlspecialchars($mensaje); ?></p>
            <a class="btn secondary" href="login_empleado.php">Volver</a>

        <?php elseif ($status === 'error'): ?>
            <p class="msg err"><?php echo htmlspecialchars($mensaje); ?></p>
            <a class="btn secondary" href="login_empleado.php">Volver</a>

        <?php else: /* ok */ ?>
            <p class="msg ok"><?php echo htmlspecialchars($mensaje); ?></p>
            <?php if (isset($empleado['Nombre'])): ?>
                <p class="msg info">Bienvenido, <strong><?php echo htmlspecialchars($empleado['Nombre']); ?></strong></p>
            <?php endif; ?>
            <a class="btn" href="panel_empleado.php">Ir al Panel</a>
            <small class="info">Si no te redirige automáticamente, haz clic en "Ir al Panel".</small>
        <?php endif; ?>

    </div>
</body>
</html>
