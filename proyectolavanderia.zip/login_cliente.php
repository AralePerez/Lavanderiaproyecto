<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login Cliente</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
        background: linear-gradient(135deg, #74ebd5, #9face6);
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .contenedor {
        background: #fff;
        padding: 35px 45px;
        border-radius: 15px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
        text-align: center;
        width: 350px;
    }

    h2 {
        color: #004080;
        margin-bottom: 25px;
    }

    label {
        font-weight: bold;
        display: block;
        text-align: left;
        margin-bottom: 5px;
    }

    input[type="email"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
    }

    input[type="submit"] {
        background-color: #004080;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.3s ease;
    }

    input[type="submit"]:hover {
        background-color: #0066cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    a {
        display: inline-block;
        margin-top: 15px;
        color: #004080;
        text-decoration: none;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    a:hover {
        color: #0066cc;
        text-decoration: underline;
    }
</style>
</head>

<body>
    <div class="contenedor">
        <h2>🔐 Iniciar Sesión Cliente</h2>

        <form method="POST" action="validarc.php">
            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" required>

            <label for="password">Contraseña:</label>
            <input type="password" name="password" id="password" required>

            <input type="submit" value="Entrar">
        </form>

        <a href="menu_cliente.php">⬅️ Volver</a>
    </div>
</body>
</html>
 


