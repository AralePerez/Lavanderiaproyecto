<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/config/database.php';

// NO usar mysqli aquí

$nombre    = $_POST['nombre'];
$telefono  = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo    = $_POST['correo'];
$password  = $_POST['password'];
$confirmar = $_POST['password_confirm'];

// 1️⃣ Validar contraseñas
if ($password !== $confirmar) {
    die("❌ Las contraseñas no coinciden");
}

// 2️⃣ Verificar si el correo ya existe
$existe = R::findOne('cliente', ' correo = ? ', [$correo]);
if ($existe) {
    die("❌ Este correo ya está registrado");
}

// 3️⃣ Crear cliente
$cliente = R::dispense('cliente');
$cliente->nombre    = $nombre;
$cliente->telefono  = $telefono;
$cliente->direccion = $direccion;
$cliente->correo    = $correo;

// 4️⃣ Encriptar contraseña
$cliente->password = password_hash($password, PASSWORD_DEFAULT);

// 5️⃣ Guardar en BD
R::store($cliente);

// 6️⃣ Redirigir al login
header("Location: login_cliente.php");
exit;
