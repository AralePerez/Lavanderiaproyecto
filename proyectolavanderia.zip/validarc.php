<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config/database.php';

$correo   = $_POST['correo'] ?? '';
$password = $_POST['password'] ?? '';

if ($correo === '' || $password === '') {
    die('❌ Datos incompletos');
}

$cliente = R::findOne('cliente', 'correo = ?', [$correo]);

if (!$cliente) {
    die('❌ Correo no registrado');
}

if (password_verify($password, $cliente->password)) {

    // 🔐 Guardar sesión
    $_SESSION['cliente'] = $cliente->id;
    $_SESSION['nombre']  = $cliente->nombre;

    // 🚀 REDIRECCIÓN (SIN NINGUNA SALIDA ANTES)
    header("Location: Panel_del_cliente.php");
    exit;
}

die('❌ Contraseña incorrecta');

